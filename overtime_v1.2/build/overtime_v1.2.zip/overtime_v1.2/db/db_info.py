class Connect:

    # # test server
    # host = "125.143.154.68"
    # port = 3307
    # database = "webserver"
    # username = "scott"
    # password = "!Jhlee0809"        

    # doochpump 화성공장 hr server 
    host = "106.248.19.234"
    port = 3306
    database = "webserver"
    username = "scott"
    password = "!Jhlee0809"        
        
